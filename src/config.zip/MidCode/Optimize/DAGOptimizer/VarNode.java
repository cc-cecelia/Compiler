package MidCode.Optimize.DAGOptimizer;

import MidCode.Value.Value;

public class VarNode extends Node{
    public VarNode(int id) {
        super(id);
    }


}
