package MidCode.Value.FuncValue;

public enum BType {
    INT,
    VOID
}
