package MidCode.Optimize;

public class FuncOptimizer {
    // 删除无用函数，没被调用过的


}
