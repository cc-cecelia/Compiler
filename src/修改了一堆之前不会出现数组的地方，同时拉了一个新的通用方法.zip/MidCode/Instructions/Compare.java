package MidCode.Instructions;

import Fronted.ASTComponent.CmpType;
import MidCode.Optimize.DAGOptimizer.DAG;
import MidCode.Table.Symbol;
import MidCode.Table.VarSymbol;
import MidCode.Value.IntegerValue.IntegerValue;
import MidCode.Value.StringValue;
import MidCode.Value.SymbolValue;
import MidCode.Value.Value;
import Target.GRF.GRF;
import Target.GRF.Register;
import Target.Immediate;
import Target.Instructions.*;
import Target.Operand;
import Target.Symbol.MipsController;
import Target.Tag;

import java.util.List;

public class Compare extends Instruction {
    private Value left;
    private Value right;
    private CmpType type;
    private String target;

    public Compare(Value left, Value right, CmpType type, String target) {
        this.left = left;
        this.right = right;
        this.type = type;
        this.target = target;
    }

    @Override
    public String toString() {
        return "cmp " + left + " " + right + "\n" +
                type + " " + target + "\n";

    }

    @Override
    public List<MipsCode> toMipsCode(boolean isOptimized) {
        //mipsCodes.add(new Annotation(this.toString()));
        List<MipsCode> container = isOptimized ? optimizedMips : this.mipsCodes;


        Register rs = GRF.getSReg();
        if (left instanceof IntegerValue intLeft) {
            if (((IntegerValue) left).getDim0Value() == 0) {
                rs = GRF.getReg("0");
            } else {
                rs.setOccupied();
                container.add(new Load(InstrType.li, rs, null, new Immediate(intLeft.getDim0Value())));
            }
        } else {
            rs.setOccupied();
            getOperand(left,rs,container);

//            Operand leftAddr = MipsController.getAddr((Symbol) left);
//
//            if (((Symbol) left).isGlobal()) {
//                container.add(new Load(InstrType.la, rs, null, leftAddr));
//                container.add(new Load(InstrType.lw,rs,null ,rs));
//            } else {
//                container.add(new Load(InstrType.lw, rs, leftAddr, GRF.getReg("sp")));
//            }
        }

        InstrType instrType = switch (type) {
            case NEQ -> InstrType.bne;
            case EQL -> InstrType.beq;
            case GRE -> InstrType.bgt;
            case GEQ -> InstrType.bge;
            case LSS -> InstrType.blt;
            case LEQ -> InstrType.ble;
            default -> throw new IllegalStateException("Unexpected value: " + type);
        };
        Register rt;
        if (right instanceof IntegerValue) {
            if (((IntegerValue) right).getDim0Value() == 0) {
                instrType = switch (instrType) {
                    case bne -> InstrType.bnez;
                    case beq -> InstrType.beqz;
                    case blt -> InstrType.bltz;
                    case ble -> InstrType.blez;
                    case bgt -> InstrType.bgtz;
                    case bge -> InstrType.bgez;
                    default -> throw new IllegalStateException("Unexpected value: " + instrType);
                };
                container.add(new Branch(instrType, rs, new Tag(target)));
                rs.release();
                return container;
            } else {
                rt = GRF.getSReg();
                container.add(new Load(InstrType.li, rt, null, new Immediate(((IntegerValue) right).getDim0Value())));
            }
        } else {
            rt = GRF.getSReg();
            rt.setOccupied();
            getOperand(right,rt,container);
//            Operand rightAddr = MipsController.getAddr((Symbol) right);
//            if (((Symbol) right).isGlobal()) {
//                container.add(new Load(InstrType.la, rt, null, rightAddr));
//                container.add(new Load(InstrType.lw,rt,null,rt));
//            } else {
//                container.add(new Load(InstrType.lw, rt, rightAddr, GRF.getReg("sp")));
//            }
        }

        container.add(new Branch(instrType, rs, rt, new Tag(target)));
        rs.release();
        rt.release();
        return container;
    }

//    private Register getOperand(Value operand1, Register targetReg, List<MipsCode> container) {
//        if (operand1 instanceof SymbolValue val) {
//            Register offTmp = GRF.getTReg();
//            Operand base = MipsController.getAddr(val.getSymbol());
//            if (val.isGlobal()) {
//                container.add(new Load(InstrType.la,targetReg,null,base));
//                if (val.getOffset() instanceof VarSymbol varOff) {
//                    Operand offAddr = MipsController.getAddr(varOff);
//                    if (varOff.isGlobal()) {
//                        container.add(new Load(InstrType.la, offTmp, null, offAddr));
//                        container.add(new Load(InstrType.lw,offTmp,null,targetReg));
//                    } else {
//                        container.add(new Load(InstrType.lw,offTmp,offAddr,GRF.getReg("sp")));
//                    }
//                    container.add(new Alu(InstrType.sll,offTmp,offTmp,new Immediate(2)));
//                    container.add(new Alu(InstrType.addu,targetReg,targetReg,offTmp));
//                    container.add(new Load(InstrType.lw,targetReg,null,targetReg));
//                } else if (val.getOffset() instanceof IntegerValue intOff) {
//                    int totalOff = intOff.getDim0Value() * 4;
//                    container.add(new Load(InstrType.lw,targetReg,new Immediate(totalOff),targetReg));
//                }
//            }
//            else {
//                Operand baseAddr = MipsController.getAddr(val.getSymbol());
//                if (val.isParam()) {
//                    container.add(new Load(InstrType.lw,targetReg,baseAddr,GRF.getReg("sp"))); // rs存的是数组首地址
//                    if (val.getOffset() instanceof VarSymbol varOff) {
//                        Register offReg = GRF.getTReg();
//                        Operand offAddr = MipsController.getAddr(varOff);
//                        if (varOff.isGlobal()) {
//                            container.add(new Load(InstrType.la,offReg, null, offAddr));
//                            container.add(new Load(InstrType.lw,offReg, null, offReg));
//                            container.add(new Alu(InstrType.sll,offReg,offReg,new Immediate(2)));
//                            container.add(new Alu(InstrType.addu,targetReg, targetReg, offReg));
//                            container.add(new Load(InstrType.lw,targetReg, null ,targetReg));
//                        } else {
//                            container.add(new Load(InstrType.lw,offReg,offAddr,GRF.getReg("sp")));
//                            container.add(new Alu(InstrType.sll,offReg,offReg,new Immediate(2)));
//                            container.add(new Alu(InstrType.addu,targetReg, targetReg, offReg));
//                            container.add(new Load(InstrType.lw,targetReg,null,targetReg));
//                        }
//                    }
//                    else if (val.getOffset() instanceof IntegerValue intOff) {
//                        int total = 4 * intOff.getDim0Value();
//                        container.add(new Load(InstrType.lw,targetReg,new Immediate(total),targetReg));
//                    }
//                }
//                else {
//                    if (val.getOffset() instanceof VarSymbol varOff) {
//                        Operand offAddr = MipsController.getAddr(varOff);
//                        if (varOff.isGlobal()) {
//                            container.add(new Load(InstrType.la,targetReg,null,offAddr));
//                            container.add(new Load(InstrType.lw,targetReg,null, targetReg));
//                        } else {
//                            container.add(new Load( InstrType.lw, targetReg,offAddr,GRF.getReg("sp")));
//                        }
//                        container.add(new Alu(InstrType.sll,targetReg, targetReg,new Immediate(2))); // rs 存的是total偏移比如说16
//                        container.add(new Alu(InstrType.addiu, targetReg, targetReg, baseAddr));
//                        container.add(new Alu(InstrType.addu,targetReg,targetReg,GRF.getReg("sp")));
//                        container.add(new Load(InstrType.lw,targetReg, null ,targetReg));
//                    }
//                    else if (val.getOffset() instanceof IntegerValue intOff) {
//                        int totalSp= ((Immediate)baseAddr).getNumber() + 4 * intOff.getDim0Value();
//                        container.add(new Load(InstrType.lw,targetReg,new Immediate(totalSp),GRF.getReg("sp")));
//                    }
//                }
//            }
//        } else if (operand1 instanceof VarSymbol) {
//            if (((VarSymbol) operand1).isGlobal()) {
//                container.add(new Load(InstrType.la, targetReg, null, MipsController.getAddr((VarSymbol) operand1)));
//                container.add(new Load(InstrType.lw, targetReg, null, targetReg));
//            } else {
//                container.add(new Load(InstrType.lw, targetReg,
//                        MipsController.getAddr(((VarSymbol) operand1)),
//                        GRF.getReg("sp"))); // rs = op1
//            }
//        }
//        return targetReg;
//    }
    @Override
    public Instruction optimize() {
        return this;
    }

    @Override
    public void DAGoptimize(DAG dag) {
        String op = type.toString() + "_jump";
        Value res = new StringValue(target);

        dag.parse(left, right, res, DAG.getOp(op));
    }

    public String getTarget() {
        return target;
    }

    public String getType() {
        return type.toString();
    }

    public Value getLeft() {
        return left;
    }

    public Value getRight() {
        return right;
    }

    @Override
    public Instruction reconstruct(Value tmp, Value newA) {

        // tmp = a; x = b + tmp;
        Value newOp1 = this.left;
        Value newOp2 = this.right;
        boolean flag = false;
        if (left.equals(tmp)) {
            flag = true;
            newOp1 = newA;
        }
        if (right.equals(tmp)) {
            flag = true;
            newOp2 = newA;
        }

        if (flag) {
            return new Compare(newOp1,newOp2,this.type,this.target);
        } else {
            return this;
        }
    }

}
