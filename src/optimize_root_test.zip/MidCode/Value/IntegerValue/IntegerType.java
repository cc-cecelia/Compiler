package MidCode.Value.IntegerValue;

public enum IntegerType {
    DIM0,
    DIM1,
    DIM2
}
