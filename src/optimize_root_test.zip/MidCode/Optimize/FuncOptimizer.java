package MidCode.Optimize;

public class FuncOptimizer {

}
