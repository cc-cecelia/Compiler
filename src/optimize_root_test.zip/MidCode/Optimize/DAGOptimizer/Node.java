package MidCode.Optimize.DAGOptimizer;

public class Node {
    protected int nodeNum;
    protected int left;
    protected int right;

    private String op;

    public Node(int nodeNum,int left, int right, String op) {
        this.nodeNum = nodeNum;
        this.left = left;
        this.right = right;
        this.op = op;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Node node) {
            return node.op.equals(this.op) && node.left == this.left && node.right == this.right;
        }
        return false;
    }
}
