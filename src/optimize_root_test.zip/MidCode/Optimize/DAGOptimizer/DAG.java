package MidCode.Optimize.DAGOptimizer;

import MidCode.BasicBlock;
import MidCode.Instructions.Calculate;
import MidCode.Instructions.Instruction;
import MidCode.Instructions.MemCpy;
import MidCode.Instructions.ValAssign;
import MidCode.Value.Value;

import java.util.ArrayList;
import java.util.HashMap;

public class DAG {
    private BasicBlock basicBlock;

    private int number;
    private HashMap<Value, Integer> DAGTable;
    private ArrayList<Node> midNodes;


    public DAG(BasicBlock basicBlock) {
        this.basicBlock = basicBlock;
        DAGTable = new HashMap<>();
        midNodes = new ArrayList<>();
    }

    public void construct() {
        for (Instruction instruction : basicBlock.getMidCodes()) {
            if (instruction instanceof Calculate cal) {
                 Value left = cal.getOperand1();
                 Value right = cal.getOperand2();
                 String op = cal.getOp();
                 Value res = cal.getLVal();

                 int i = getNumber(left);
                 int j = getNumber(right);

                 int oper = getMidNode(new Node(-1,i,j,op));

                 update(res,oper);
            } else if (instruction instanceof ValAssign) {

            } else if (instruction instanceof MemCpy) {

            }
        }
    }

    public int getNumber(Value value) {
        if (DAGTable.containsKey(value)) {
            return DAGTable.get(value);
        } else {
            DAGTable.put(value,++number);
            return number;
        }
    }

    public int getMidNode(Node node) {
        if (midNodes.contains(node)) {
            return node.nodeNum;
        } else {
            node.nodeNum = ++number;
            midNodes.add(node);
            return number;
        }
    }

    public void update(Value res, int newNum) {
        if (DAGTable.containsKey(res)) {
            DAGTable.compute(res,(key,value) -> newNum);
        } else {
            DAGTable.put(res,newNum);
        }
    }

}
