package MidCode;

import MidCode.Instructions.Instruction;
import Target.Instructions.MipsCode;

import java.util.ArrayList;
import java.util.List;

public class BasicBlock extends Instruction{
    private String name;
    private ArrayList<Instruction> midCodes;
    private ArrayList<BasicBlock> motherBlocks;
    private BasicBlock trueDaughter;
    private BasicBlock falseDaughter;

    private ArrayList<Instruction> optimized;


    public BasicBlock(String name) {
        this.name = name;
        midCodes = new ArrayList<>();
        motherBlocks = new ArrayList<>();
        optimized = new ArrayList<>();
    }

    public BasicBlock(ArrayList<Instruction> instructions) {
        this.midCodes = instructions;
    }
    public void addInstr(Instruction instruction) {
        midCodes.add(instruction);
    }

    public void addInstrs(List<Instruction> instructionList) {
        midCodes.addAll(instructionList);
    }

    public void addMother(BasicBlock block) {
        if (motherBlocks.contains(block)) {
            return;
        }
        motherBlocks.add(block);
    }

    public void addDaughter(BasicBlock block) {
        trueDaughter = block;
    }

    public void setTrueDaughter(BasicBlock trueDaughter) {
        this.trueDaughter = trueDaughter;
    }

    public void setFalseDaughter(BasicBlock falseDaughter) {
        this.falseDaughter = falseDaughter;
    }

    public ArrayList<Instruction> getMidCodes() {
        return midCodes;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("-------------basic block "+name +"-------------" +"\n");
        for (Instruction instruction : optimized) {
            sb.append(instruction.toString());
        }
        sb.append("-------------"+name + " block end" +"-------------" + "\n");
        return sb.toString();
    }

    @Override
    public List<MipsCode> toMipsCode() {
        return null;
    }

    // 块内优化
    public Instruction optimize() {
        for (Instruction old : midCodes) {
            optimized.add(old.optimize());
        }
        return new BasicBlock(optimized);
    }
}
