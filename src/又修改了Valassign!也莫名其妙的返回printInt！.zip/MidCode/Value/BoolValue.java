package MidCode.Value;

public class BoolValue extends Value{
    private boolean aBoolean;

    public BoolValue(boolean aBoolean) {
        this.aBoolean = aBoolean;
    }

    public boolean getRes() {
        return aBoolean;
    }
    @Override
    public String toString() {
        return null;
    }

}
