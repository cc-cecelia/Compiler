package MidCode.Table;

public enum SymbolType {
    Func,
    VAR_0,
    VAR_1,
    VAR_2;
}
