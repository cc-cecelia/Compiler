package MidCode.Instructions;

import MidCode.Optimize.DAGOptimizer.DAG;
import MidCode.Table.VarSymbol;
import MidCode.Value.IntegerValue.IntegerValue;
import MidCode.Value.Value;
import MidCode.Value.VoidValue;
import Target.GRF.GRF;
import Target.Immediate;
import Target.Instructions.*;
import Target.Symbol.MipsController;
import Target.Symbol.MipsSymbol;

import java.util.List;

public class PrintInt extends Print{
    private Value value;

    public PrintInt(Value value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "print_int, " + value.toString() + "\n";
    }

    public List<MipsCode> toMipsCode(boolean isOptimized) {
        List<MipsCode> container = isOptimized ? optimizedMips : this.mipsCodes;

        container.add(new Annotation(this.toString()));

        container.add(new Load(InstrType.li, GRF.getReg("v0"),null, new Immediate(1)));
        if (value instanceof IntegerValue integer) {
            container.add(new Load(InstrType.li,GRF.getReg("a0"),null,new Immediate(integer.getDim0Value())));
        } else if (value instanceof VarSymbol symbol) {
            MipsSymbol mipsSymbol = MipsController.getSym(symbol);
            if (mipsSymbol.getUser() instanceof  Immediate) {
                container.add(new Load(InstrType.lw, GRF.getReg("a0"),new Immediate(mipsSymbol.getSpOffset()),GRF.getReg("sp")));
            } else {
                container.add(new Move(InstrType.move, GRF.getReg("a0"),mipsSymbol.getUser()));
            }
        }
        container.add(new Syscall(InstrType.syscall));
        return container;
    }

    public Value getValue() {
        return value;
    }

    @Override
    public void DAGoptimize(DAG dag) {
        String op = "print_int";
        Value res = new VoidValue();
        dag.parse(value,null,res, DAG.getOp(op));
    }

    @Override
    public Instruction reconstruct(VarSymbol tmp, VarSymbol newA) {
        // tmp = a; print tmp;
        if (value instanceof VarSymbol var && var.equals(tmp)) {
            return new PrintInt(newA);
        } else {
            return this;
        }
    }
}
