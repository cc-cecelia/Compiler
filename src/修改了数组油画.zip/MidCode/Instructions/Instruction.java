package MidCode.Instructions;

import MidCode.Optimize.DAGOptimizer.DAG;
import MidCode.Table.VarSymbol;
import Target.Instructions.MipsCode;

import java.util.ArrayList;
import java.util.List;

public abstract class Instruction {

    public abstract String toString();
    protected List<MipsCode> mipsCodes = new ArrayList<>();
    protected List<MipsCode> optimizedMips = new ArrayList<>();

    public abstract List<MipsCode> toMipsCode(boolean isOptimized);
    public abstract Instruction optimize();
    public abstract void DAGoptimize(DAG dag);

    public Instruction reconstruct(VarSymbol tmp, VarSymbol newA) {
        return this;
    }

}
